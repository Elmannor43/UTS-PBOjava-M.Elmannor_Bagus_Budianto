/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

/**
 *
 * @author DELL
 */
public class latihan3 {
    public static void main(String[] args) {
        String matakuliah = "Pemrograman Berbasis Objek";
        String singkatan = "PBO";
        String sks = "3";
        String pengajar = "Didi Andriawan";
        
        System.out.println("Matakuliah  = "+matakuliah);
        System.out.println("Singkatan   = "+singkatan);
        System.out.println("SKS         = "+sks);
        System.out.println("Pengajar    = "+pengajar);
        
    }
}
