/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class latihan6 {
    public static void main(String[] args) {
        int angka;
        Scanner inputan = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Masukkan Angka : ");
        angka = inputan.nextInt();
        System.out.println("Angka yang diinputakan adalah "+angka);
        
        
        
        
    }
}
