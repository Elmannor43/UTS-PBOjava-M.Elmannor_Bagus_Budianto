/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum3;

/**
 *
 * @author DELL
 */
public class Latihan1 {
    public static void main(String[] args) {
        int angka_sistem = 100;
        if (angka_sistem < 150) {
            System.out.println("Ini merupakan statement if");
        }
        System.out.println("program selesai");
    }
}

