/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum3;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Soal2 {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Masukkan bulan ke- = ");
       int Bulan = input.nextInt();
       
        System.out.println("");       
    switch (Bulan) {
        case 1:
            System.out.println("Bulan ke-" + Bulan + " adalah januari");
            break;
        case 2:
            System.out.println("Bulan ke-" + Bulan + " adalah february");
            break;
        case 3:
            System.out.println("Bulan ke-" + Bulan + " adalah maret");
            break;
        case 4:
            System.out.println("Bulan ke-" + Bulan + " adalah april");
            break;
        case 5:    
            System.out.println("Bulan ke-" + Bulan + " adalah mei");
            break;
        case 6:    
            System.out.println("Bulan ke-" + Bulan + " adalah juni");
            break;
        case 7:    
            System.out.println("Bulan ke-" + Bulan + " adalah juli");
            break;
        default:
            System.out.println("Tidak ada Bulan ke-" + Bulan);
        }    
    }
}

