/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package percabangan;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class LatihanInputScanner1 {
    public static void main(String[] args) {
        
        Scanner s1 = new Scanner(System.in);
        System.out.print("Masukkan nilai1 = ");
        int nilai1 = s1.nextInt();
        
        System.out.print("Masukkan nilai2 = ");
        int nilai2 = s1.nextInt();
        
        if (nilai1 < nilai2) {
            System.out.println("Nilai terbesar = "+nilai2);
        }else{
            System.out.println("Nilai terbesar = "+nilai1);
            
        }
    }
}
