/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package percabangan;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class StrukturHari {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Masukkan hari ke- = ");
       int noHari = input.nextInt();
       
        System.out.println("");
        
    switch (noHari) {
        case 1:
            System.out.println("Hari ke-" + noHari + " adalah senin");
            break;
        case 2:
            System.out.println("Hari ke-" + noHari + " adalah selasa");
            break;
        case 3:
            System.out.println("Hari ke-" + noHari + " adalah rabu");
            break;
        case 4:
            System.out.println("Hari ke-" + noHari + " adalah kamis");
            break;
        case 5:    
            System.out.println("Hari ke-" + noHari + " adalah jum'at");
            break;
        case 6:    
            System.out.println("Hari ke-" + noHari + " adalah sabtu");
            break;
        case 7:    
            System.out.println("Hari ke-" + noHari + " adalah minggu");
            break;
        default:
            System.out.println("Tidak ada hari ke-" + noHari);
    }    
    }
}
