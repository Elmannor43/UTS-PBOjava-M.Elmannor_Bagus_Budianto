/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class LatihanPenjumlahanScanner {
    public static void main(String[] args) {
        
        Scanner s1 = new Scanner(System.in);
        System.out.println("Masukkan nilaiA = ");
        int nilai1 = s1.nextInt();
        
        System.out.println("Masukkan nilaiB = ");
        int nilai2 = s1.nextInt();
        
        System.out.println("Nilai A = "+ nilai1);
        System.out.println("Nilai B = "+ nilai2);
        int jumlah = nilai1 + nilai2;
        System.out.println("Jumlah = " + jumlah);
    }
}
