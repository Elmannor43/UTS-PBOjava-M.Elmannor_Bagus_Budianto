/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class InputJOP {
    public static void main(String[] args) {
        //input nama
        String nama = JOptionPane.showInputDialog("Masukkan nama anda!");
        int umur = Integer.parseInt (JOptionPane.showInputDialog ("Masukkan umur anda!"));
        //print
        System.out.println("Hai " + nama + ", apa kabar? Tidak terasa sekarang anda sudah " + umur + " tahun.");
        
               
    }
}
