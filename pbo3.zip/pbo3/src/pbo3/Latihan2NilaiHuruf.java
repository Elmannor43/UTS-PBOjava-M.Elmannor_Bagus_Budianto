/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Latihan2NilaiHuruf {
    public static void main(String[] args) {
        Scanner inp = new Scanner (System.in);
        
        System.out.print("Masukkan nama anda = ");
        String Nama = inp.next();
        
        System.out.print("Masukkan NIM = ");
        String nim = inp.next();
        
        System.out.print("Masukkan nilai = ");
        int nilai = inp.nextByte();
        
        if (nilai <=55) {
            System.out.println("E ");
        } else if (nilai <=65) {
            System.out.println("D ");
        } else if (nilai <=75) {
            System.out.println("C ");
        } else if (nilai <=85) {
            System.out.println("B ");
        } else if (nilai <=100) {
            System.out.println("A ");
        } else {
            System.out.println("Cum Laude ");
            
        }
        
    }
}
