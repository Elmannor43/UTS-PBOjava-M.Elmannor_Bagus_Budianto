/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Latihan1Kelulusan1 {
    public static void main(String[] args) {
        //buat scanner
        Scanner inp = new Scanner (System.in);
        //ambil nama
        System.out.print("Masukkan nama anda = ");
        String Nama = inp.next();
        //ambil nim
        System.out.print("Masukkan NIM = ");
        String nim = inp.next();
        //ambil nilai
        System.out.print("Masukkan Nilai = ");
        int nilai = inp.nextByte();
        //print
        if(nilai >= 50) {
            System.out.println("Anda lulus ");
        } else {
            System.out.println("Anda tidak lulus ");
        }
        
    }
}
