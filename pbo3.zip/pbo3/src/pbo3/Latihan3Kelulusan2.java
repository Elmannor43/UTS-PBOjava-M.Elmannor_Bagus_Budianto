/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Latihan3Kelulusan2 {
    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        //ambilnama
        System.out.print("Masukkan nama anda = ");
        String nama = inp.next();
        
        //ambil jenis kelamin
        System.out.print("Masukkan jenis kelamin = ");
        String kelamin = inp.next();
        
        //ambil tinggi badan
        System.out.print("Masukkan tinggi badan = ");
        int tinggi = inp.nextInt();
        
        if ("laki-laki".equals(kelamin)) {
            if (tinggi > 170) {
                System.out.println("Selamat anda lulus");
            }else{
                System.out.println("anda gagal");
            }
        }else if("perempuan".equals(kelamin)) {
            if (tinggi > 160) {
                System.out.println("selamat anda lulus");
            }else{
                System.out.println("anda gagal");
                
            }
        }
    }
} 
