/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo2;

/**
 *
 * @author DELL
 */
public class Kalimat {
    public static void main(String[] args) {
       // Buat  variabel 
       String subjek      = "Saya "; 
       String prediket    = "menulis ";
       String objek       = "program Java "; 
       String keterangan  = "hari ini "; 
       // Print kalimat S+P+O+K 
       System.out.println(subjek+prediket+objek+keterangan); 
    }
}
