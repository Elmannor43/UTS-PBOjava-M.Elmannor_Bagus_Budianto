/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo2;

/**
 *
 * @author DELL
 */
public class Pembagian {
    public static void main(String[] args) {
        int a = 20;
        int b = 8;
        float hasilpembagian = (float) a / b;
        
        System.out.println("Nilai A         = " + a);
        System.out.println("Nilai B         = " + b);
        System.out.println("Hasil Pembagian = " + hasilpembagian);
}
}