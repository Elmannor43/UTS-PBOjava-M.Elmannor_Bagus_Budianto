/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo2;

/**
 *
 * @author DELL
 */
public class Penjumlahan {
    public static void main(String[] args) {
        int nilaiA = 1500;
        int nilaiB = 75;
        int jumlah = nilaiA + nilaiB;
        
        System.out.println("Nilai A = " + nilaiA);
        System.out.println("Nilai B = " + nilaiB);
        System.out.println("Jumlah  = " + jumlah);
        
    }
}
